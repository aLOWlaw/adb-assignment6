from django.contrib import admin
from .models import BooksModel

admin.site.register(BooksModel)
