from rest_framework import views, generics
from .models import HistoryModel
from books.models import BooksModel
from books.selrializers import BooksModelSerializer
from .serializers import HistoryModelSerializer
from rest_framework.permissions import AllowAny, IsAuthenticated
from .recommendations import recommend_books_based_on_category
from bson import ObjectId
from rest_framework.response import Response



class HistoryCreateView(generics.CreateAPIView):
    queryset = HistoryModel.objects.all()
    serializer_class = HistoryModelSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        book_data = serializer.validated_data.pop('book')
        book, created = BooksModel.objects.get_or_create(**book_data)
        serializer.save(user=self.request.user, book=book)


class UserCategoryRecommendationsView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = BooksModelSerializer
    lookup_field = "_id"

    def get(self, request):
        user = request.user
        recommendations = recommend_books_based_on_category(user._id)
        serializer = self.get_serializer(recommendations, many=True)
        return Response(serializer.data)
