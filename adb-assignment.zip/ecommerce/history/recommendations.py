from .models import HistoryModel
from books.models import BooksModel
from collections import Counter
from bson import ObjectId


def get_user_category_preferences(user_id):
    interactions = HistoryModel.objects.filter(user__id=ObjectId(user_id))
    categories = [interaction.book.category for interaction in interactions]
    category_counter = Counter(categories)
    return category_counter


def get_purchased_books(user_id):
    purchased_books = HistoryModel.objects.filter(user__id=ObjectId(user_id), interaction="purchase").values_list('book__id', flat=True)
    return set(purchased_books)

def recommend_books_based_on_category(user_id, top_n=10):
    # Get user's category preferences
    user_preferences = get_user_category_preferences(user_id)
    purchased_books = get_purchased_books(user_id)

    if not user_preferences:
        # Return some popular or random books if no preferences found
        return BooksModel.objects.exclude(_id__in=purchased_books)[:top_n]

    # Get the most preferred categories
    most_preferred_categories = user_preferences.most_common()
    
    # Collect books from the preferred categories
    recommended_books = []
    for category, _ in most_preferred_categories:
        books = BooksModel.objects.filter(category=category).exclude(_id__in=purchased_books)
        recommended_books.extend(books)

    # Deduplicate books
    recommended_books = list(set(recommended_books))
    
    # Sort books by category preference count
    recommended_books.sort(key=lambda book: user_preferences[book.category], reverse=True)
    
    # Return the top N recommended books
    return recommended_books[:top_n]
