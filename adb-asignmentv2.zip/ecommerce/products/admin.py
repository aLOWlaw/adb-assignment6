from django.contrib import admin
from .models import ProductsModel
# Register your models here.
admin.site.register(ProductsModel)